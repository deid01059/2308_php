<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    public function search(Request $req)
    {
        Log::debug('리퀘드스값입니다'.$req);
        $result = User::select('u_id')->where('u_id',$req->u_id) ->get();

        return $result;
    }

}
