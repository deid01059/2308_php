<template>
    <!-- 헤더 영역 -->
    <div class="header">
        <div class="header_frame">
            <div class="header_frame_left">
                <router-link :to="'/main'" >
                    <img src="/img/logo_steam.svg" class="header_img">
                </router-link>
                <div class="header_menu">상점</div>
                <div class="header_menu">커뮤니티</div>
                <div class="header_menu">정보</div>
                <div class="header_menu">지원</div>
            </div>
            <div class="header_frame_right">
                <a href="https://store.steampowered.com/about/" class="header_menu2">steam설치</a>
                <router-link :to="'/login'" class="header_menu2">로그인</router-link>
                <router-link :to="'/regist'" class="header_menu2">회원가입</router-link>
            </div>
        </div>
    </div>
    <!-- 메인 영역 -->
    <router-view></router-view>

    <!-- 푸터 영역 -->
    <div class="footer">

    </div>
</template>
<script>
import BoardComponent from './BoardComponent.vue'
import LoginComponent from './LoginComponent.vue'
import RegistComponent from './RegistComponent.vue'
export default {

    name: 'MainComponent',
    props: {

    },
    
    components: {
        BoardComponent,LoginComponent,RegistComponent
    },

    data() {
        return {
            setting: '',
        }
    },

    methods: {
    }
}
</script>
