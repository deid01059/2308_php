<template>
	<div class="list_container">
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
		<div class="listbox">게시글</div>
	</div>
</template>
<script>
export default {
	name: 'BoardList',
	props: {

	},
	
	components: {

	},

	data() {
		return {
			setting: '',
		}
	},

	created() {

	},

	mounted() {

	},

	methods: {

	}
}
</script>