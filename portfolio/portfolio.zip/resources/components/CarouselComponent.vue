<template>
	<div class="car_container center">
		<div class="car_left"><img src="/img/chevron-left.svg"></div>
		<div class="car_right"><img src="/img/chevron-right.svg"></div>
		<div class="car_main">
			<div class="car_box">이미지</div>
			<div class="car_box">이미지</div>
			<div class="car_box">이미지</div>
		</div>
	</div>
</template>
<script>
export default {
	name: 'CarouselComponent',
	props: {

	},
	
	components: {

	},

	data() {
		return {
			setting: '',
		}
	},

	created() {

	},

	mounted() {

	},

	methods: {

	}
}
</script>