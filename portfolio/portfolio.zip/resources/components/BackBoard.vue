<template>
	<div class="board_bg">
		<NavComponent></NavComponent>
	</div>
</template>
<script>
import NavComponent from './NavComponent.vue'
export default {
	name: '',
	props: {

	},
	
	components: {
		NavComponent
	},

	data() {
		return {
			setting: '',
		}
	},

	created() {

	},

	mounted() {

	},

	methods: {

	}
}
</script>