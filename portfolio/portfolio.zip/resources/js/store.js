import { createStore } from "vuex";
import axios from "axios";

const store = createStore({
	// state() : data를 저장하는 영역
	state() {
		return {
		fageFlg: 0, // 탭ui용 플래그
		}
	},

	// mutations : 데이터 수정용 함수 저장 영역
	mutations: {
	
	},

	// actions : ajax로 서버에 데이터를 요청할 때나 시간 함수등 비동기 처리는 actions에 정의
	actions: {
		actionIdChk(){
			
			let id = document.querySelector('#u_id').value
			console.log(id)
			const URL = '/api/regist'
			const HEADER = {
				headers: {
					'Authorization': 'Bearer mykey',
					'Content-Type': 'multipart/form-data',
				}
			};
				const formData = new FormData();
				formData.append('u_id', id);
			// const DATA = {			
			// 	'u_id' : id
			// };
			console.log(formData);
			console.log(formData.id);
			axios.get(URL, formData, HEADER)
			.then(res => {
				console.log('엑시오스실행')
				console.log(res)	
			})
			.catch(err => {
				console.log(err.response.data);
			})
		},
	}
});

export default store;